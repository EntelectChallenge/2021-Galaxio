#!/bin/bash
./runner-publish/run.sh &
./engine-publish/run.sh &
./logger-publish/run.sh